<?php
		$connection = mysqli_connect("localhost","root","","emrs") or die(mysql_error());
?>
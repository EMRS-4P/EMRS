<?php

if(!empty($_GET))
	{
	require_once('../connection/connect.php');

		$firstname =  $_GET['firstname'];
		$lastname =  $_GET['lastname'];
		$email =  $_GET['email'];
		$username =  $_GET['username'];
		$pass =  $_GET['pass'];
		$compass =  $_GET['compass'];
		$dob =  $_GET['dob'];
		$gender =  $_GET['gender'];
		$mobile =  $_GET['mobile'];
		$land =  $_GET['land'];
		$house =  $_GET['house'];
		$city =  $_GET['city'];
		$state =  $_GET['state'];
		$Contact = $mobile.' ,'.$land.'.';
		$Address = $house.' ,'.$city.' ,'.$state.'.';
	 

	 $querry1= $connection->query("INSERT INTO receptionist_registration (FirstName, LastName, E_mail, UserName, Password, Confirm_Password, Date_Of_Birth, Gender, Contact_Number,Address) values('$firstname', '$lastname', '$email', '$username', '$pass', '$compass', '$dob', '$gender', '$mobile', '$land', '$Address')");

	
}
if(connection){
	 echo "<script>alert('Successfuly Register!!!')</script>";
       echo "<script>window.open('../index.php')</script>";

  mysql_close($connection);
}
	
	

	

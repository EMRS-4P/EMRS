<?php
  session_start();
  include_once("connection/connect.php");
  if(isset($_GET['id'])!="")
  {
  $delete=$_GET['id'];
  $delete=mysql_query("DELETE FROM patient_registration WHERE Registration_Number='$delete'");
  if($delete)
  {
	  header("Location:../reception_nurse/nursehome.php");
  }
  else
  {
	  echo mysql_error();
  }
  }


?>
<?PHP
	session_start();
	require_once('../connection/connect.php');
	
	$UserName = $_SESSION["username"];
	$password = $_SESSION["password"];
	$query ="select * from doctor_registration where Username='$UserName' and Password ='$password'";
	
	$result =mysqli_query($connection,$query);
	
	$medofficer_details = mysqli_fetch_assoc($result);
	
?>
<!doctype html>

<html lang="en-gb" class="no-js">
<!--<![endif]-->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<title>Regional Poison Information System</title>
<meta name="description" content="">
<meta name="author" content="Group4p">

<link rel="stylesheet" href="../css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="../css/isotope.css" media="screen" />
<link rel="stylesheet" href="../js/fancybox/jquery.fancybox.css" type="text/css" media="screen" />
<link href="../css/animate.css" rel="stylesheet" media="screen">
<!-- Owl Carousel Assets -->
<link href="../js/owl-carousel/owl.carousel.css" rel="stylesheet">
<link rel="stylesheet" href="../css/styles.css" />
<!-- Font Awesome -->
<link href="../font/css/font-awesome.min.css" rel="stylesheet">

<style>
.column {
    float: left;
    width: 50%;
    padding: 10px;
}


.row:after {
    content: "";
    display: table;
    clear: both;
} 

.not-active:link {
    color: #000000;
	text-decoration:none;
}

/* visited link */
.not-active:visited {
    color: #000000;
}

/* mouse over link */
.not-active:hover {
    color: #000000;
}

/* selected link */
.not-active:active {
    color: #000000;
}
</style>
</head>

<body>
<header class="header">
  <div class="container">
    <nav class="navbar navbar-inverse" role="navigation">
      <div class="navbar-header">   
	  <a href="#" class="not-active scroll-top animated fadeIn "><h1> <?php echo $medofficer_details['FirstName'].' '.$medofficer_details['LastName']  ?></h1></a>
      </div>
      <!--/.navbar-header-->
      <div id="main-nav" class="collapse navbar-collapse ">
        <ul class="nav navbar-nav" id="mainNav">
		  <li></li>
		  <li><a href="#patient_registration" class="scroll-link">Patients registration</a></li>
          <li><a href="#setting" class="scroll-link">Manage profile</a></li>
          <li><a href="../index.php" class="scroll-link">Log out</a></li> <!-- connect with loging page -->
        </ul>
      </div>
	 
      <!--/.navbar-collapse--> 
    </nav>
    <!--/.navbar--> 
  </div>
  <!--/.container--> 
</header>
<!--/.header-->
<div id="#top"></div>
<section id="home">
  <div class="banner-container"> <img src="../images/banner-bg.jpg" alt="banner" />
    <div class="container banner-content">
      <div class="hero-text animated fadeIn">
        <h1 class="responsive-headline" style="../font-size: 40px;">   Welcome  <?php echo $medofficer_details['FirstName'].' '.$medofficer_details['LastName']  ?> </h1>
        
       </div>
    </div>
  </div>
</section>
<section id="patient_registration" class="page-section color">
<div class="parlex-back">
  <div class="container" style="width:60%;margin-top:10px;text-align: center; color:rgba(10,10,10,0.9) ;background-color:rgba(250,250,250,0.9) ;">
    <div class="heading text-center"> 
      <!-- Heading -->
      <h2>Patients Registration</h2>
    </div>	
	<div class="panel">
	<div class="card" >
      <img src="../images/im-7.jpg" class="card-img-top" style="height: 150px ;width: 100%">
      <h2 > Patient's Registration Form </h2>
      <div class="card-body">
         <div class="row"> 
      <form class="form-horizontal" action="register_medofficer.php" method="GET">
                      <!-- Title -->
					  <div class="form-group">
                        <label class="control-label col-lg-3" for="title">Patient ID:</label>
                        <div class="col-lg-4">
                          <input type="text"   name="patientid" placeholder="Patient ID" required data-validation-required-message="Please enter patient ID" class="form-control" style="float: left">  
                        </div>
						</div>
                      <div class="form-group">
                        <label class="control-label col-lg-3" for="title">Name:</label>
                        <div class="col-lg-4">
                          <input type="text"   name="firstname" placeholder="First Name" required data-validation-required-message="Please enter FirstName" class="form-control" style="float: left">  
                        </div>
                        <div class="col-lg-4">
                          <input type="text"   name="lastname" placeholder="Last Name" required data-validation-required-message="Please enter LastName" class="form-control" style="float: right">  
                        </div>
                      </div>
                      
                       
                        <div class="form-group ">
                        <label class="control-label col-lg-3">Date of Birth :</label>
                         <div class="col-lg-3">
                        <input type="date"  name ="dob" class="form-control" placeholder="Date of Birth">
                    </div>
                  </div>
                      
                        <div class="form-group">
                        <label class="control-label col-lg-3" for="tags">Gender :</label>
                        <div class="col-lg-2">
                          <input type="radio" name="gender" value="Female"  >Female
                       </div>
                          <div class="col-lg-2">
                          <input type="radio" name="gender" value="Male" >  Male
                        </div>
                      </div>
                       <div class="form-group">
                        <label class="control-label col-lg-3">Contact:</label>
                         <div class="col-lg-3">
                        <input type="number"  name ="mobile" placeholder="Mobile Number" class="form-control"  style="float: left">
                     </div>
                     <div class="col-lg-3">
                          <input type="number" name ="land" placeholder="Land Number " class="form-control"  style="float: right;">
                        </div>  
                        </div>   


                      <div class="form-group">
                        <label class="control-label col-lg-3" for="tags">Address :</label>
                        <div class="col-lg-3">
                           <input type="text"  name ="house" id="inputAddress2" placeholder="House No/Name" >
                           </div>
                          <div class="col-lg-3">
                             <input type="text"  name ="city" id="inputCity" placeholder="City" >
                          </div>
                          <div class="col-lg-3">
                          <select id="inputState"  name ="state"  >
								<option value="Ampara">Ampara</option>
								<option value="Anuradhapura">Anuradhapura</option>
								<option value="Badulla">Badulla</option>
								<option value="Batticaloa">Batticaloa</option>
								<option value="Colombo">Colombo</option>
								<option value="Galle">Galle</option>
								<option value="Gampaha">Gampaha</option>
								<option value="Hambantota">Hambantota</option>
								<option value="Jaffna">Jaffna</option>
								<option value="Kalutara">Kalutara</option>
								<option value="Kandy">Kandy</option>
								<option value="Kegalle">Kegalle</option>
								<option value="Kilinochchi">Kilinochchi</option>
								<option value="Kurunegala">Kurunegala</option>
								<option value="Mannar">Mannar</option>
								<option value="Matale">Matale</option>
								<option value="Matara">Matara</option>
								<option value="Monaragala">Monaragala</option>
								<option value="Mullaitivu">Mullaitivu</option>
								<option value="Nuwara Eliya">Nuwara Eliya</option>
								<option value="Polonnaruwa">Polonnaruwa</option>
								<option value="Puttalam">Puttalam</option>
								<option value="Ratnapura">Ratnapura</option>
								<option value="Trincomalee">Trincomalee</option>
								<option value="Vavuniya">Vavuniya</option>
                        </select>
                          </div>
                      </div>
					  
					  <div class="form-group">
                        <label class="control-label col-lg-3" for="title">Gaudian Name:</label>
                        <div class="col-lg-4">
                          <input type="text"   name="name" placeholder="Name" required data-validation-required-message="Please enter your Name" class="form-control" style="float: left">  
                        </div>
                      </div>
					  
					  <div class="form-group">
                        <label class="control-label col-lg-3" for="tags">Gaurdian Address :</label>
                        <div class="col-lg-3">
                           <input type="text"  name ="house" id="inputAddress2" placeholder="House No/Name" >
                           </div>
                          <div class="col-lg-3">
                             <input type="text"  name ="city" id="inputCity" placeholder="City" >
                          </div>
                          <div class="col-lg-3">
                          <select id="inputState"  name ="state"  >
								<option value="Ampara">Ampara</option>
								<option value="Anuradhapura">Anuradhapura</option>
								<option value="Badulla">Badulla</option>
								<option value="Batticaloa">Batticaloa</option>
								<option value="Colombo">Colombo</option>
								<option value="Galle">Galle</option>
								<option value="Gampaha">Gampaha</option>
								<option value="Hambantota">Hambantota</option>
								<option value="Jaffna">Jaffna</option>
								<option value="Kalutara">Kalutara</option>
								<option value="Kandy">Kandy</option>
								<option value="Kegalle">Kegalle</option>
								<option value="Kilinochchi">Kilinochchi</option>
								<option value="Kurunegala">Kurunegala</option>
								<option value="Mannar">Mannar</option>
								<option value="Matale">Matale</option>
								<option value="Matara">Matara</option>
								<option value="Monaragala">Monaragala</option>
								<option value="Mullaitivu">Mullaitivu</option>
								<option value="Nuwara Eliya">Nuwara Eliya</option>
								<option value="Polonnaruwa">Polonnaruwa</option>
								<option value="Puttalam">Puttalam</option>
								<option value="Ratnapura">Ratnapura</option>
								<option value="Trincomalee">Trincomalee</option>
								<option value="Vavuniya">Vavuniya</option>
                        </select>
                          </div>
                      </div>
					  
					  <div class="form-group">
                        <label class="control-label col-lg-3">Gaurdian Contact:</label>
                         <div class="col-lg-3">
                        <input type="number"  name ="mobile" placeholder="Mobile Number" class="form-control"  style="float: left">
                     </div>
                     <div class="col-lg-3">
                          <input type="number" name ="land" placeholder="Land Number " class="form-control"  style="float: right;">
                        </div>  
                        </div>   
                      
                      <div class="col-lg-offset-3 col-lg-3">
                           <button type="submit" class="btn btn-danger" style="float: left">Register</button>
						</div>
						<div class="col-lg-offset-0 col-lg-3">
                          <button type="reset" class="btn btn-default" style="float: right;">Update</button>
                       
						</div>
						<div class="col-lg-offset-0 col-lg-3">
                          <button type="reset" class="btn btn-default" style="float: right;">Add Poison</button>
                       
						</div>
                     </form>
                   </div>
                 </div>
			   </div>
			   </div>
			   </div>
  </div>
  <!--/.container--> 
</section>

<section id="patients">
<?php
require_once('search.php');

?>
</section>
<section id="setting" class="page-section color">
  <div class="container">
    <div class="heading text-center"> 
      <!-- Heading -->
      <h2>Manage profile</h2>
      
    </div>
   <?php
//update user image
  if(isset($_POST['submit'])) {
  $photo = new Media();
  $user_id = (int)$_POST['user_id'];
  $photo->upload($_FILES['file_upload']);
  if($photo->process_user($user_id)){
    $session->msg('s','photo has been uploaded.');
    redirect('edit_account.php');
    } else{
      $session->msg('d',join($photo->errors));
      redirect('edit_account.php');
    }
  }
?>
<?php
 //update user other info
  if(isset($_POST['update'])){
    $req_fields = array('name','username' );
    validate_fields($req_fields);
    if(empty($errors)){
             $id = (int)$_SESSION['user_id'];
           $name = remove_junk($db->escape($_POST['name']));
       $username = remove_junk($db->escape($_POST['username']));
            $sql = "UPDATE users SET name ='{$name}', username ='{$username}' WHERE id='{$id}'";
    $result = $db->query($sql);
          if($result && $db->affected_rows() === 1){
            $session->msg('s',"Acount updated ");
            redirect('edit_account.php', false);
          } else {
            $session->msg('d',' Sorry failed to updated!');
            redirect('edit_account.php', false);
          }
    } else {
      $session->msg("d", $errors);
      redirect('edit_account.php',false);
    }
  }
?>

<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
  <div class="col-md-6">
      <div class="panel panel-default">
        <div class="panel-heading">
          <div class="panel-heading clearfix">
            <span class="glyphicon glyphicon-camera"></span>
            <span>Change My photo</span>
          </div>
        </div>
        <div class="panel-body">
          <div class="row">
            <div class="col-md-4">
                <img class="img-circle img-size-2" src="uploads/users/<?php echo $user['image'];?>" alt="">
            </div>
            <div class="col-md-8">
              <form class="form" action="edit_account.php" method="POST" enctype="multipart/form-data">
              <div class="form-group">
                <input type="file" name="file_upload" multiple="multiple" class="btn btn-default btn-file"/>
              </div>
              <div class="form-group">
                <input type="hidden" name="user_id" value="<?php echo $user['id'];?>">
                 <button type="submit" name="submit" class="btn btn-warning">Change</button>
              </div>
             </form>
            </div>
          </div>
        </div>
      </div>
  </div>
  <div class="col-md-6">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <span class="glyphicon glyphicon-edit"></span>
        <span>Edit My Account</span>
      </div>
      <div class="panel-body">
          <form method="post" action="edit_account.php?id=<?php echo (int)$user['id'];?>" class="clearfix">
            <div class="form-group">
                  <label for="name" class="control-label">Name</label>
                  <input type="name" class="form-control" name="name" value="<?php echo remove_junk(ucwords($user['name'])); ?>">
            </div>
            <div class="form-group">
                  <label for="username" class="control-label">Username</label>
                  <input type="text" class="form-control" name="username" value="<?php echo remove_junk(ucwords($user['username'])); ?>">
            </div>
            <div class="form-group clearfix">
                    <a href="change_password.php" title="change password" class="btn btn-danger pull-right">Change Password</a>
                    <button type="submit" name="update" class="btn btn-info">Update</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>
  
  
  </div>
  <!--/.container--> 
</section>
<script src="../js/modernizr-latest.js"></script> 
<script src="../js/jquery-1.8.2.min.js" type="text/javascript"></script> 
<script src="../js/bootstrap.min.js" type="text/javascript"></script> 
<script src="../js/jquery.isotope.min.js" type="text/javascript"></script> 
<script src="../js/fancybox
/jquery.fancybox.pack.js" type="text/javascript"></script> 
<script src="../js/jquery.nav.js" type="text/javascript"></script> 
<script src="../js/jquery.fittext.js"></script> 
<script src="../js/waypoints.js"></script> 
<script src="../js/custom.js" type="text/javascript"></script> 
<script src="../js/owl-carousel/owl.carousel.js"></script>

</body>
</html>                 